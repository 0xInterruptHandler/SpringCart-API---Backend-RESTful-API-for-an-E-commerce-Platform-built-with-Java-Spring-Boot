package com.oxinterrupthandler.SpringCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
